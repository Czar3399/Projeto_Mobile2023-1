import { StyleSheet} from "react-native";

const styles = StyleSheet.create({
    container: {
        flexDirection: 'row',
        width: '100%',
        height: '180px',
        backgroundColor: 'yellow',
        borderRadius: '10px'
    },
    viewImagem: {
        width: '20%',
        padding: '5px',
    },
    viewDados: {
        width: '80%',
        padding: '20px'
    },
    poster: {
        width: '100%',
        height: '100%',
        borderRadius: '15px',
    },
    titulo: {
        fontSize: 20,
        fontWeight: 'bold',
        textAlign: 'center'
    },
    sinopse: {
        marginBottom: 10
    },
    btnComprar:{
        borderRadius: 15
    }
});

export default styles;