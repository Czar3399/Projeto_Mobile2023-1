import { Text, Image, StyleSheet, View } from 'react-native';
import Teste from './src/components/Teste';
import Contador from './src/components/Contador';
import { useEffect, useState } from 'react';
import Filme from './src/components/Filme';

{/*
export default function App() {
  return (
    <View style={styles.container}>
      <Teste texto= "Olá pessoal!"> 
        <Image source={{
          uri: 'https://reactnative.dev/img/tiny_logo.png'
        }} style={styles.img}/>
      </Teste>
    </View>
  );
}

export default function App() {
  
  return (
    <View style={styles.container}>
      <Contador />
      <Contador />

    </View>
  );
}


export default function App() {
  
  let [loading, setLoading] = useState (false)

  useEffect(() => {
    setTimeout(() => {
      setLoading(true);
    }, 2000);
  }, [])

  return (
    <View style={styles.container}>
      {loading === true ? <Contador/> : <Text>Carregando ...</Text>}
    </View>
  );
}
*/}

{/*
export default function App() {
    return (
    <View style={styles.container}>
      <Filme />
    </View>
  );
}
*/}

const listaFilmes = [
  {
    titulo: "Avatar",
    sinopse: "Sinopse do filme...",
    urlPoster: "https://a-static.mlcdn.com.br/1500x1500/poster-cartaz-avatar-2-o-caminho-da-agua-a-pop-arte-poster/poparteskins2/15983151125/05b13cd9c00028a453c58a879eceb94e.jpeg"
  },
  {
    titulo: "One piece: Red",
    sinopse: "Sinopse do filme ...",
    urlPoster: "https://img.elo7.com.br/product/zoom/1EDFF3A/big-poster-do-anime-one-piece-tamanho-90x-0-cm-lo122-one-piece.jpg"
  },
  {
    titulo: "John Wick 4",
    sinopse: "Sinopse do filme ...",
    urlPoster: "https://sm.ign.com/ign_br/screenshot/default/jw4-2025x3000-online-character-1sht-keanu-v2_gfrq.jpg"
  }
]

{/*
export default function App() {
  return (
  <View style={styles.container}>
    <Filme filme={listaFilmes[0]}/>
    <Filme filme={listaFilmes[1]}/>
    <Filme filme={listaFilmes[2]}/>
  </View>
);
}


export default function App() {
  return (
  <View style={styles.container}>
    {listaFilmes.map(filme => <Filme filme={filme}/>)}
  </View>
);
}
*/}

export default function App() {

  console.log("entrou")
  const[filmes, setFilmes] = useState([])

  // useEffect( () => {}, [])
  useEffect( () => {
    console.log("Entrou no useeffect")
    fetch("https://api.otaviolube.com/api/filmes").then(result => result.json()).then(objeto => {
      console.log(objeto.data);
      console.log("passou do useeffect")
      let resultado = objeto.data
      setFilmes(resultado)
      console.log(filmes)

    }).catch(error => console.log(error))
  }, [])

  {/*
  if(filmes && filmes.length){
    return (
      <View style={styles.container}>
        {listaFilmes.map(filme => <Filme filme={filme}/>)}
      </View>
    );
  }
  */}

  if (filmes && filmes.length) {
    return (
       <View>
       {
         filmes.map(filme => (
           <View>
          <Text> {filme.id}</Text>
          <Text> {filme.attributes.titulo} </Text>
          <Text> {filme.attributes.sinopse} </Text>
          <Text> {filme.attributes.createdAt}</Text>
          </View>
         ))
       }
        
      </View>
     )
  }

  return (<View>
    <Text> Carregando filmes </Text>
   </View>)
}


const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'green',
    alignItems: 'center',
    justifyContent: 'center',
  },
  texto: {
    color: 'white',
    fontSize: '20px',
    fontWeight: 'bold'
  }
});
